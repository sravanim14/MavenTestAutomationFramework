package utils.pageObjects;

public interface BoardPageElements {

    String boardPageTitle = "//h1[@class='js-board-editing-target board-header-btn-text']";
}
