package utils.pageObjects;

public interface SettingsPageElements {

    String settingsTabActive = "//a[@data-tab='settings']";
}
